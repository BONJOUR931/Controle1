package exercice02;

public class Point_test {

	
	public static void main(String[] args) {
		Point P=new Point("A",2,1,3);
		P.affiche();
		P.translate(3,5,5);
		P.affiche();
		Point D=new Point("B",1,1,2);
		System.out.println(D.distance(P));
		
		
	}

	

	
		
	}


