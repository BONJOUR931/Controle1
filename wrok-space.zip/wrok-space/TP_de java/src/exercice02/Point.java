package exercice02;

public class Point {
	String nom;
	double x ;
	 double y;
	 double z;
	

	public Point(String nom,double x ,double y,double z) {
		this.nom=nom;
		this.x=x;
		this.y=y;
		this.z=z;
	}

	public void affiche(){
		System.out.println(nom +" "+x+" "+y+" "+z);
		
	}
	public void translate(double X,double Y,double Z)
	{
		x+=X;
		y+=Y;
		z+=Z;
	}
	public  double distance(Point A)
	{
		return (Math.sqrt((this.x-A.x)*(this.x-A.x)+(this.y-A.y)*(this.y-A.y)+(this.z-A.z)*(this.z-A.z)));
		
	} 
	
}





