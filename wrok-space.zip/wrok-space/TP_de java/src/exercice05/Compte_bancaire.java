package exercice05;

public class Compte_bancaire {

 public int code;
public double solde;
public int nb_comptes=0;

public int getCode()
{
  return code;
}
public void setCode(int code)
{
	this.code=code;
	}

public double getSolde()
{
  return solde; 
}
public void setSolde(double solde) {
	this.solde = solde;
}

public int getNb_Comptes()
{
    return nb_comptes; 
}
public void setNbcomptes(int nb_comptes) {
	this.nb_comptes = nb_comptes;
}

public Compte_bancaire()
{
    nb_comptes++;
    code = nb_comptes;
}

public Compte_bancaire(double solde)
{
    nb_comptes++;
    code = nb_comptes;
    this.solde = solde;
}

public void deposer(double somme)              
{
    solde += somme;
}

public  void retirer(double sommme)              
{
    solde -= sommme;
}

public  String ToString()
{
    return "Code: " + code + " Solde: " + solde;
}


}
