package exercice05;

public class Compte_test {

	
	public static void main(String[] args) {
		Compte_bancaire C1 = new Compte_bancaire();
        Compte_Epargne C2 = new Compte_Epargne();
        ComptePayant C3 = new ComptePayant();
        C1.deposer(10000);
        C2.deposer(2000);
        C3.deposer(3000);
        C1.retirer(2000);
        C2.retirer(500);
        C3.retirer(400);
        C2.CalculerInteret();
        System.out.println(C1);
        System.out.println(C2);
        System.out.println(C3);
        
    }



	}


