package exercice05;

public class ComptePayant extends Compte_bancaire {
	 public ComptePayant()  { super();}                       
     public ComptePayant(double solde)  { super (solde);}     
     public  String ToString()                      
     {
         return "Compte Payant: "+ super.toString();
     }

     public void deposer(double somme)               
     {
         super.deposer(somme);
         super.retirer(5);
     }

     public void retirer(double somme)             
     {
         super.retirer(somme);
         super.retirer(5);
     }
 }


