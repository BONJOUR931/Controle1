package exercice05;

public class Compte_Epargne extends Compte_bancaire {
	
    
        private double tauxinteret=6;

        public double getTauxinteret()
        {
            return tauxinteret;
        }
        public void setTauxinteret(double tauxinteret){
        	this.tauxinteret=tauxinteret;
        }

        public Compte_Epargne()  { }                 

        public Compte_Epargne(double solde)  { super(solde);} 

        public void CalculerInteret()                      
        {
            deposer((getSolde() * tauxinteret)/ 100);
        }

        public String ToString()                  
        {
            return "Compte Epargne: "+ super.ToString() +" Taux inter�t: "+tauxinteret ;
        }
    }



