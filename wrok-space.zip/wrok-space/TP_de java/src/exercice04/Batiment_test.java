package exercice04;



public class Batiment_test {

	
	public static void main(String[] args ) {
		
	            Batiment B = new Batiment("ouajda","baha");
	            System.out.println(B);
	            Maison M1 = new Maison("agadir","hello",8);
	            System.out.println(M1);
	            Maison M2 = new Maison();
	            M2.adresse="ben ahmed";
	            M2.nom="Zaouia";
	            M2.nbrePieces=4;
	            System.out.println(M2);
	            System.out.println();
	            System.out.println();
	        
	    }
	
	
	}


