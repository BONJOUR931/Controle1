package exercice04;

public class Maison extends Batiment {
	public int nbrePieces ;
	public int getNbrePieces() {
		return nbrePieces;
	}
	public void setNbrePieces(int value) {
		nbrePieces = value;
	}
	public Maison()
	{super();}
	

	public Maison(String adresse,String nom,int nbrePieces) {
		super(adresse,nom);
		this.nbrePieces=nbrePieces;
		
	}
	public String toString()
	{
		return super.toString() + ". Nombre de pi�ces: " + nbrePieces;
	}
	 	
	 	

}
