package exercice04;

public class Batiment {
	 public String adresse;
	 public String nom;
    	 
		public void setAdresse(String adresse)
    	 {
         this.adresse = adresse; }
      public String getAdresse()
      {
     	 return adresse;
      }
      public void setNom(String nom)
      {
     	   this.nom=nom;
      }
      public String getNom()
      {
     	 return nom;
      }

      public Batiment(String adresse, String nom)
      {
          this.adresse = adresse;
          this.nom=nom;
      }
      

      public Batiment() {
		
	}
	public String ToString(){
      
          return "Adresse: "+adresse+"Nom: " +nom;
      }
 }   
    	