package exercice03;



public class Livre_test {
	

	
	public static void main (String[] args){
		
		Livre livre = new Livre();
		livre.setR�f("www.wikip�dia.org");
		livre.setTitre("mise en oeuvrage");
		livre.setAuteurs("Yahya FAHMI");
		livre.setAuteurs("adam ERRAJI");
		livre.setAuteurs("amine TAZI");
		livre.setMaisonEdition("DAR nachr");
		livre.setAnnee(1999);
		System.out.println(livre.toString());
		//testons : l'auteur Yahya FAHMI admis � la liste des auteurs de ce livre ou non :
		System.out.println(livre.chercherAuteurs("Yahya FAHMI"));
		//testons : ce livre traite le th�me oeuvrage ou  non :
		System.out.println(livre.chercherTheme("oeuvrage"));
				
			
			
			
				 
			 }
		
		
		
}
