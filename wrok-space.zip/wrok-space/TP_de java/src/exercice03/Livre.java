
package exercice03;

import java.util.ArrayList;
public class Livre {

	
	private String r�f;
	private String titre;
	private ArrayList<String>auteurs=new ArrayList();
	private int annee;
	private String maisonEdition;

 
	
	public void setR�f(String r�f) {
		this.r�f = r�f;
	}

	public String getR�f() {
		return r�f;
	}
 
	public String getTitre() {
		return titre;
	}
 
	public void setTitre(String titre) {
		this.titre = titre;
	}
 
	
	public ArrayList getAuteurs() {
		return auteurs;
	}
 
	public void setAuteurs(String auteur) {
		auteurs.add(auteur);
	}
	public int getAnnee() {
		return annee;
	}

	public void setAnnee(int annee) {
		this.annee = annee;
	}
 
	public String getMaisionEdition() {
		return maisonEdition;
	}
 
	public void setMaisonEdition(String maisonEdition) 
{    this.maisonEdition=maisonEdition;}
	
	//m�thode chercher auteurs : 
	public boolean chercherAuteurs(String auteur)
	{
		return auteurs.contains(auteur);
	}
	
	//m�thode chercher auteurs : 
	public boolean chercherTheme(String theme)
	{
		if(titre.indexOf(theme)>0)
			return true;
		else
			return false;
	}
	
	//m�thode toString pour afficher informations
	public String toString()
	{
		return "reference: "+r�f+"\ntitre: "+titre+"\nliste auteurs: "+auteurs+"\nann�e: "+annee+"\nmaison d'�dition: "+maisonEdition ;	
	}
	
 
}

		
	


