package exercice01;

public class Employ�_test {

	
	public static void main(String[] args) {
		Employ� e1= new Employ�(4215,"Fh","hajar",3400.3,1,5,2001,31,12,2020);

		e1.setJourActuel(21);
		e1.setMoisActuel(12);
		e1.setAnneeActuel(2021);
		
		e1.age();
		e1.anciennet�e();
		e1.augmentationDuSalaire();

		System.out.print("Employ� 1{");
		e1.afficherEmploy�();
		System.out.println("}");
	        
	           
	}

	}
