package exercice01;

public class Employ� {
	
	    
	        private int matricule;
	        private String nom;
	        private String prenom;
	        private int j_naiss,m_naiss,annee_naiss,j_emb,m_emb,annee_emb;
	        private double salaire;
	        public  void setMatricule(int matricule)
	        {
	        	this.matricule= matricule ;
	        }
	        public  int getMatricule()
	        {
	            return matricule;
	           
	        } 
	 
	        public void setNom(String nom)
	        {
	        	this.nom=nom;
	        	
	        }
	        public String getNom(){
	        	return nom;
	        }
	 
	        public void setPrenom(String prenom)
	        {
	           this.prenom=prenom;
	        }
	        public String getPrenom(){
	        	return prenom;
	        }
	        public void setSalaire(double salaire) {
				this.salaire = salaire;
			}
			public double getSalaire() {
				return salaire;
			}
			public int getJ_naiss() {
				return j_naiss;
			}
			public void setJ_naiss( int j_naiss) {
				this.j_naiss = j_naiss;
			}
			public int getM_naiss() {
				return m_naiss;
			}
			public void setM_naiss( int m_naiss) {
				this.m_naiss = m_naiss;
			}
			public int getAnnee_naiss() {
				return annee_naiss;
			}
			public void setAnnee_naiss(int annee_naiss) {
				this.annee_naiss = annee_naiss;
			}
			public int getJ_emb() {
				return j_emb;
			}
			public void setJ_emb(int j_emb) {
				this.j_emb = j_emb;
			}
			public int getM_emb() {
				return m_emb;
			}
			public void setM_Emb(int m_emb) {
				this.m_emb = m_emb;
			}
			public int getAnnee_emb() {
				return annee_emb;
			}
			public void setAnnee_emb(int annee_emb) {
				this.annee_emb = annee_emb;
			} 
			public  Employ�()
	        {
		        this.matricule =0;
				this.nom = " ";
				this.prenom = " ";
				this.j_naiss = 1;
				this.m_naiss = 1;
				this.annee_naiss = 1;
				this.j_emb = 1;
				this.m_emb = 1;
				this.annee_emb = 1;
				this.salaire = 0;}
	        
	 
			public Employ�(int matricule, String nom, String prenom, double salaire, int jourNaiss, int moisNaiss,
					int anneeNaiss, int jourEmbau, int moisEmbau, int anneeEmbau) {
				this.matricule = matricule;
				this.nom = nom;
				this.prenom = prenom;
				this.j_naiss = jourNaiss;
				this.m_naiss = moisNaiss;
				this.annee_naiss = anneeNaiss;
				this.j_emb = jourEmbau;
				this.m_emb = moisEmbau;
				this.annee_emb = anneeEmbau;
				this.salaire = salaire;
			}
			
			private int anneeActuel,moisActuel,jourActuel;
			public int getAnneeActuel() {
		     	return anneeActuel;
			}
			public void setAnneeActuel(int anneeActuel) {
				this.anneeActuel = anneeActuel;
			}
			public int getMoisActuel() {
				return moisActuel;
			}
			public void setMoisActuel(int moisActuel) {
				this.moisActuel = moisActuel;
			}
			public int getJourActuel() {
				return jourActuel;
			}
			public void setJourActuel(int jourActuel) {
				this.jourActuel = jourActuel;
			}
			
			public int age() {
				return anneeActuel-annee_naiss;
			}
			
			
			public int anciennet�e() {
				return anneeActuel-annee_emb;
			}
			
			
			public void augmentationDuSalaire() {
				if(anciennet�e() < 5)
					salaire+=0.02*salaire;
				else if(anciennet�e() < 10) 
					salaire+=0.05*salaire;
					
				else
					salaire+=0.1*salaire;
				
			}

			
			public void afficherEmploy�() {
				System.out.print( "matricule : [" + matricule + "], Nom complet : [" + nom.toUpperCase()+" "+prenom.substring(0,1).toUpperCase()+prenom.substring(1).toLowerCase()+"] , �ge : ["+age()+"], Anciennet� : ["+anciennet�e()+"], salaire:[" +salaire+"]");
			
			}


	 
	       
	       
			
	} 
	


