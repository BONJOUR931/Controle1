package yrryrufd;

public class Asqjfs {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("tdyrdydrd");

	}

}
